import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { insertCollectionSchema, insertArtworkSchema } from "@shared/schema";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Setup Replit Auth FIRST before other routes
  await setupAuth(app);
  registerAuthRoutes(app);
  
  app.get(api.collections.list.path, async (req, res) => {
    const collections = await storage.getCollections();
    res.json(collections);
  });

  app.get(api.collections.get.path, async (req, res) => {
    const collection = await storage.getCollectionBySlug(req.params.slug);
    if (!collection) {
      return res.status(404).json({ message: 'Collection not found' });
    }
    const artworks = await storage.getArtworksByCollectionId(collection.id);
    res.json({ ...collection, artworks });
  });

  app.post(api.collections.create.path, async (req, res) => {
    try {
      const input = api.collections.create.input.parse(req.body);
      const collection = await storage.createCollection(input);
      res.status(201).json(collection);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  app.post(api.artworks.create.path, async (req, res) => {
    try {
      const input = api.artworks.create.input.parse(req.body);
      const artwork = await storage.createArtwork(input);
      res.status(201).json(artwork);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  // Seed Data
  const existingCollections = await storage.getCollections();
  if (existingCollections.length === 0) {
    console.log("Seeding database...");
    
    const vault = await storage.createCollection({
      title: "The Obsidian Vault",
      slug: "obsidian-vault",
      description: "A collection of experimental digital artifacts stored in the deep archives.",
      coverImage: "https://images.unsplash.com/photo-1550684848-fac1c5b4e853?auto=format&fit=crop&q=80&w=1000",
      isLocked: true
    });

    const nature = await storage.createCollection({
      title: "Organic Matter",
      slug: "organic-matter",
      description: "Studies of natural forms and decay.",
      coverImage: "https://images.unsplash.com/photo-1518173946687-a4c8892bbd9f?auto=format&fit=crop&q=80&w=1000",
      isLocked: false
    });

    await storage.createArtwork({
      collectionId: vault.id,
      title: "Chrome Heart",
      description: "Digital sculpture, 2024",
      imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=1000",
      year: 2024,
      medium: "3D Render"
    });

    await storage.createArtwork({
      collectionId: vault.id,
      title: "Neural Pathways",
      description: "Generative art study",
      imageUrl: "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?auto=format&fit=crop&q=80&w=1000",
      year: 2023,
      medium: "Generative"
    });
    
     await storage.createArtwork({
      collectionId: nature.id,
      title: "Fern Decay",
      description: "Macro photography",
      imageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?auto=format&fit=crop&q=80&w=1000",
      year: 2024,
      medium: "Photography"
    });
    
    console.log("Database seeded!");
  }

  return httpServer;
}
