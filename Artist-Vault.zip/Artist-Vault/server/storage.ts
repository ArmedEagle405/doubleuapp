import { db } from "./db";
import {
  collections,
  artworks,
  type InsertCollection,
  type InsertArtwork,
  type Collection,
  type Artwork
} from "@shared/schema";
import { eq } from "drizzle-orm";

export interface IStorage {
  getCollections(): Promise<Collection[]>;
  getCollectionBySlug(slug: string): Promise<Collection | undefined>;
  getCollection(id: number): Promise<Collection | undefined>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  
  getArtworksByCollectionId(collectionId: number): Promise<Artwork[]>;
  createArtwork(artwork: InsertArtwork): Promise<Artwork>;
}

export class DatabaseStorage implements IStorage {
  async getCollections(): Promise<Collection[]> {
    return await db.select().from(collections);
  }

  async getCollectionBySlug(slug: string): Promise<Collection | undefined> {
    const [collection] = await db.select().from(collections).where(eq(collections.slug, slug));
    return collection;
  }

  async getCollection(id: number): Promise<Collection | undefined> {
    const [collection] = await db.select().from(collections).where(eq(collections.id, id));
    return collection;
  }

  async createCollection(collection: InsertCollection): Promise<Collection> {
    const [newCollection] = await db.insert(collections).values(collection).returning();
    return newCollection;
  }

  async getArtworksByCollectionId(collectionId: number): Promise<Artwork[]> {
    return await db.select().from(artworks).where(eq(artworks.collectionId, collectionId));
  }

  async createArtwork(artwork: InsertArtwork): Promise<Artwork> {
    const [newArtwork] = await db.insert(artworks).values(artwork).returning();
    return newArtwork;
  }
}

export const storage = new DatabaseStorage();
