import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

export * from "./models/auth";

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  coverImage: text("cover_image").notNull(),
  isLocked: boolean("is_locked").default(false), // Vault-style feature
  createdAt: timestamp("created_at").defaultNow(),
});

export const artworks = pgTable("artworks", {
  id: serial("id").primaryKey(),
  collectionId: integer("collection_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  year: integer("year"),
  medium: text("medium"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const collectionsRelations = relations(collections, ({ many }) => ({
  artworks: many(artworks),
}));

export const artworksRelations = relations(artworks, ({ one }) => ({
  collection: one(collections, {
    fields: [artworks.collectionId],
    references: [collections.id],
  }),
}));

export const insertCollectionSchema = createInsertSchema(collections).omit({ id: true, createdAt: true });
export const insertArtworkSchema = createInsertSchema(artworks).omit({ id: true, createdAt: true });

export type Collection = typeof collections.$inferSelect;
export type InsertCollection = z.infer<typeof insertCollectionSchema>;
export type Artwork = typeof artworks.$inferSelect;
export type InsertArtwork = z.infer<typeof insertArtworkSchema>;

export type CreateCollectionRequest = InsertCollection;
export type CreateArtworkRequest = InsertArtwork;
export type UpdateCollectionRequest = Partial<InsertCollection>;
export type UpdateArtworkRequest = Partial<InsertArtwork>;
