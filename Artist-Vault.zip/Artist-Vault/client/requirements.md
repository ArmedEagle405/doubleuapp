## Packages
framer-motion | Page transitions and scroll animations
clsx | Class name utility
tailwind-merge | Class merging utility

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  mono: ["'Space Mono'", "monospace"],
  sans: ["'Inter'", "sans-serif"],
}
