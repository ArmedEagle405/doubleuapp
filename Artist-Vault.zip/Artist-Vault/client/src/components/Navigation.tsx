import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { LogOut, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";

export function Navigation() {
  const [location, setLocation] = useLocation();
  const { user, isLoading, logout } = useAuth();

  const links = [
    { href: "/", label: "Home" },
    { href: "/shop", label: "Shop" },
    { href: "/videos", label: "Music/Videos" },
    { href: "/connect", label: "Connect" },
    { href: "/about", label: "About" },
    { href: "/contact", label: "Contact" },
    { href: "/account", label: "Account" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => setLocation("/")}
          className="text-3xl font-black font-mono tracking-tighter hover:text-accent transition-colors cursor-pointer bg-none border-none p-0 m-0"
          data-testid="button-logo"
        >
          W
        </button>

        {/* Links */}
        <div className="hidden md:flex items-center gap-8">
          {links.map((link) => (
            <button
              key={link.href}
              onClick={() => setLocation(link.href)}
              className={cn(
                "text-sm font-mono uppercase tracking-wider transition-colors cursor-pointer bg-none border-none p-0 m-0",
                location === link.href
                  ? "text-accent"
                  : "text-muted-foreground hover:text-foreground"
              )}
              data-testid={`button-nav-${link.label.toLowerCase()}`}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* Auth Button */}
        <div className="flex items-center gap-2">
          {!isLoading && user ? (
            <>
              <span className="text-xs font-mono text-muted-foreground hidden sm:inline">
                {user.email || "User"}
              </span>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => logout()}
                className="flex items-center gap-2"
                data-testid="button-logout"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Logout</span>
              </Button>
            </>
          ) : !isLoading ? (
            <Button
              size="sm"
              className="bg-accent text-accent-foreground hover:bg-accent/90 flex items-center gap-2"
              onClick={() => (window.location.href = "/api/login")}
              data-testid="button-login"
            >
              <LogIn className="w-4 h-4" />
              <span className="hidden sm:inline">Login</span>
            </Button>
          ) : null}
        </div>

        {/* Mobile Menu Placeholder */}
        <div className="md:hidden text-muted-foreground">☰</div>
      </div>
    </nav>
  );
}
