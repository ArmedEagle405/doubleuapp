import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { X, Calendar, PenTool } from "lucide-react";
import type { Artwork } from "@shared/schema";
import { Badge } from "@/components/ui/badge";

interface ArtworkModalProps {
  artwork: Artwork | null;
  isOpen: boolean;
  onClose: () => void;
}

export function ArtworkModal({ artwork, isOpen, onClose }: ArtworkModalProps) {
  if (!artwork) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl bg-card border-border p-0 gap-0 overflow-hidden rounded-none vault-border">
        <div className="grid md:grid-cols-[1.5fr,1fr] h-[85vh] md:h-[600px]">
          {/* Image Side */}
          <div className="relative bg-black h-[50vh] md:h-full flex items-center justify-center p-4">
            <img 
              src={artwork.imageUrl} 
              alt={artwork.title}
              className="max-h-full max-w-full object-contain"
            />
            {/* Tech details on image */}
            <div className="absolute top-4 left-4 font-mono text-xs text-white/50">
              IMG_REF: {artwork.id.toString().padStart(4, '0')}
            </div>
          </div>

          {/* Details Side */}
          <div className="flex flex-col h-full border-l border-border">
            <DialogHeader className="p-6 pb-2 text-left">
              <div className="flex justify-between items-start">
                <DialogTitle className="font-mono text-2xl font-bold uppercase text-primary">
                  {artwork.title}
                </DialogTitle>
                <button 
                  onClick={onClose}
                  className="p-1 hover:bg-white/10 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="h-1 w-20 bg-accent mt-4 mb-2" />
            </DialogHeader>
            
            <div className="p-6 pt-2 flex-1 overflow-y-auto space-y-6">
              <div className="flex gap-4 font-mono text-sm text-muted-foreground border-b border-border pb-4">
                {artwork.year && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>{artwork.year}</span>
                  </div>
                )}
                {artwork.medium && (
                  <div className="flex items-center gap-2">
                    <PenTool className="w-4 h-4" />
                    <span>{artwork.medium}</span>
                  </div>
                )}
              </div>

              <div className="prose prose-invert prose-sm max-w-none text-muted-foreground/80 font-sans">
                {artwork.description || "No description provided for this archived item."}
              </div>

              <div className="mt-auto pt-6">
                <Badge variant="outline" className="rounded-none border-primary/20 text-xs font-mono">
                  VERIFIED_ORIGINAL
                </Badge>
              </div>
            </div>

            {/* Footer metadata */}
            <div className="p-4 bg-muted/20 border-t border-border mt-auto font-mono text-[10px] text-muted-foreground flex justify-between">
              <span>ARCHIVE_DATE: {new Date(artwork.createdAt!).toLocaleDateString()}</span>
              <span>SECURE_VIEW</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
