import { Link } from "wouter";
import { motion } from "framer-motion";
import { Lock, Unlock } from "lucide-react";
import type { Collection } from "@shared/schema";
import { cn } from "@/lib/utils";

interface CollectionCardProps {
  collection: Collection;
  index: number;
}

export function CollectionCard({ collection, index }: CollectionCardProps) {
  return (
    <Link href={`/collection/${collection.slug}`}>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.1, duration: 0.5 }}
        className="group relative cursor-pointer h-full"
      >
        <div className={cn(
          "vault-border h-full bg-card p-1 transition-all duration-300",
          "hover:translate-x-[-4px] hover:translate-y-[-4px] hover:shadow-[4px_4px_0px_0px_rgba(255,255,255,0.1)]",
          collection.isLocked && "opacity-75 grayscale hover:grayscale-0 hover:opacity-100"
        )}>
          {/* Image Container */}
          <div className="relative aspect-[4/3] overflow-hidden bg-secondary">
            <img
              src={collection.coverImage}
              alt={collection.title}
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            
            {/* Overlay */}
            <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
            
            {/* Status Icon */}
            <div className="absolute top-4 right-4 bg-black/80 p-2 backdrop-blur-sm border border-white/10">
              {collection.isLocked ? (
                <Lock className="w-4 h-4 text-muted-foreground" />
              ) : (
                <Unlock className="w-4 h-4 text-accent" />
              )}
            </div>
            
            {/* Tech Decoration */}
            <div className="absolute bottom-2 left-2 text-[10px] font-mono text-white/50 bg-black/50 px-1">
              ID: {collection.slug.toUpperCase()}
            </div>
          </div>

          {/* Content */}
          <div className="p-4 space-y-3">
            <div className="flex justify-between items-start">
              <h3 className="font-mono text-xl font-bold leading-none tracking-tight group-hover:text-accent transition-colors">
                {collection.title}
              </h3>
              <span className="text-xs font-mono text-muted-foreground">
                {new Date(collection.createdAt!).getFullYear()}
              </span>
            </div>
            
            <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
              {collection.description}
            </p>

            <div className="pt-4 flex items-center justify-between border-t border-border/50">
              <span className="text-xs font-mono text-primary group-hover:underline decoration-accent underline-offset-4">
                ACCESS_VAULT
              </span>
              <div className="w-2 h-2 bg-muted-foreground group-hover:bg-accent transition-colors rounded-full" />
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
