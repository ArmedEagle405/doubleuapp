import { cn } from "@/lib/utils";

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-accent selection:text-white">
      {/* Top Bar - Status Line */}
      <div className="h-1 w-full bg-gradient-to-r from-transparent via-primary/20 to-transparent" />

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-12 md:py-16">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto">
        <div className="container mx-auto px-4 py-6 flex flex-col md:flex-row justify-between items-center text-xs text-muted-foreground font-mono">
          <p>MUSIC_PLATFORM: ONLINE</p>
          <p>© {new Date().getFullYear()} DOUBLEU. ALL RIGHTS RESERVED.</p>
        </div>
      </footer>
    </div>
  );
}
