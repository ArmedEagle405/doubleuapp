import { useParams } from "wouter";
import { Layout } from "@/components/Layout";
import { useCollection } from "@/hooks/use-collections";
import { useArtworks } from "@/hooks/use-artworks";
import { ArtworkModal } from "@/components/ArtworkModal";
import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, ArrowLeft, Lock, Unlock } from "lucide-react";
import { Link } from "wouter";
import type { Artwork } from "@shared/schema";
import { cn } from "@/lib/utils";

export default function CollectionDetail() {
  const params = useParams();
  const slug = params.slug!;
  
  const { data: collection, isLoading: isCollectionLoading } = useCollection(slug);
  const { data: artworks, isLoading: isArtworksLoading } = useArtworks(collection?.id || 0);

  const [selectedArtwork, setSelectedArtwork] = useState<Artwork | null>(null);

  if (isCollectionLoading) {
    return (
      <Layout>
        <div className="h-[80vh] flex items-center justify-center">
          <Loader2 className="w-10 h-10 animate-spin text-accent" />
        </div>
      </Layout>
    );
  }

  if (!collection) {
    return (
      <Layout>
        <div className="h-[50vh] flex flex-col items-center justify-center gap-4">
          <h1 className="font-mono text-2xl">404: COLLECTION_NOT_FOUND</h1>
          <Link href="/" className="text-primary hover:text-accent underline font-mono">
            RETURN_TO_BASE
          </Link>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12 border-b border-border pb-8"
      >
        <Link href="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-6 font-mono group">
          <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          BACK_TO_VAULT
        </Link>
        
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="px-2 py-0.5 bg-secondary text-secondary-foreground text-[10px] font-mono uppercase tracking-wider">
                SEQ_ID: {collection.id}
              </span>
              {collection.isLocked ? (
                <span className="flex items-center gap-1 text-[10px] font-mono text-muted-foreground">
                  <Lock className="w-3 h-3" /> LOCKED
                </span>
              ) : (
                <span className="flex items-center gap-1 text-[10px] font-mono text-accent">
                  <Unlock className="w-3 h-3" /> UNLOCKED
                </span>
              )}
            </div>
            <h1 className="text-4xl md:text-6xl font-bold font-mono uppercase tracking-tighter text-primary">
              {collection.title}
            </h1>
          </div>
          <div className="max-w-md text-sm text-muted-foreground border-l border-accent/30 pl-4 font-light">
            {collection.description}
          </div>
        </div>
      </motion.div>

      {/* Artworks Grid */}
      {isArtworksLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 animate-pulse">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="aspect-square bg-secondary/50" />
          ))}
        </div>
      ) : artworks?.length === 0 ? (
        <div className="h-40 border border-dashed border-border flex items-center justify-center text-muted-foreground font-mono text-sm">
          NO_ITEMS_IN_COLLECTION
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {artworks?.map((artwork, idx) => (
            <motion.div
              key={artwork.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              onClick={() => setSelectedArtwork(artwork)}
              className="group cursor-pointer"
            >
              <div className="relative aspect-square overflow-hidden bg-card vault-border">
                <img 
                  src={artwork.imageUrl} 
                  alt={artwork.title}
                  className="w-full h-full object-cover transition-all duration-500 group-hover:scale-110 group-hover:opacity-80"
                />
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <span className="font-mono text-xs text-white border border-white/50 px-2 py-1">
                    VIEW_ASSET
                  </span>
                </div>
              </div>
              <div className="mt-3 flex justify-between items-baseline">
                <h3 className="text-sm font-medium truncate pr-2 group-hover:text-accent transition-colors">
                  {artwork.title}
                </h3>
                <span className="text-[10px] font-mono text-muted-foreground whitespace-nowrap">
                  {artwork.year || '----'}
                </span>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <ArtworkModal 
        artwork={selectedArtwork} 
        isOpen={!!selectedArtwork} 
        onClose={() => setSelectedArtwork(null)} 
      />
    </Layout>
  );
}
