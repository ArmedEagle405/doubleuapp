import { Layout } from "@/components/Layout";
import { motion } from "framer-motion";

export default function Connect() {
  return (
    <Layout>
      <section className="py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl"
        >
          <h1 className="text-5xl md:text-7xl font-black font-mono tracking-tighter mb-8">
            CONNECT
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl border-l-2 border-accent pl-6 py-2">
            Latest updates, news, and announcements from the studio.
          </p>
        </motion.div>
      </section>

      <div className="space-y-8">
        {[
          { date: "Dec 29, 2024", title: "Artist Vault Launch", desc: "The digital archive is now live." },
          { date: "Dec 20, 2024", title: "New Collection: Organic Matter", desc: "Exploring natural forms and decay through photography." },
          { date: "Dec 15, 2024", title: "Behind the Scenes", desc: "Studio workflow and creative process documented." },
        ].map((update, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: idx * 0.1 }}
            className="border border-border p-6 hover:bg-card/50 transition-colors"
          >
            <span className="text-xs font-mono text-accent">{update.date}</span>
            <h3 className="text-2xl font-mono font-bold mt-2">{update.title}</h3>
            <p className="text-muted-foreground mt-2">{update.desc}</p>
          </motion.div>
        ))}
      </div>
    </Layout>
  );
}
