import { Layout } from "@/components/Layout";
import { motion } from "framer-motion";

export default function Videos() {
  return (
    <Layout>
      <section className="py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl"
        >
          <h1 className="text-5xl md:text-7xl font-black font-mono tracking-tighter mb-8">
            MUSIC / VIDEOS
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl border-l-2 border-accent pl-6 py-2">
            Music videos, studio sessions, performance clips, and exclusive behind-the-scenes content from DoubleU.
          </p>
        </motion.div>
      </section>

      <div className="h-64 flex items-center justify-center border border-dashed border-border rounded">
        <span className="font-mono text-muted-foreground">VIDEO_LIBRARY_LOADING...</span>
      </div>
    </Layout>
  );
}
