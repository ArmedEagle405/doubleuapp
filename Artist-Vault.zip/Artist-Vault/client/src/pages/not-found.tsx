import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background text-foreground p-4">
      <div className="max-w-md w-full border border-destructive/50 p-8 text-center bg-destructive/5">
        <AlertTriangle className="w-16 h-16 text-destructive mx-auto mb-6" />
        <h1 className="font-mono text-4xl font-bold mb-2">ERROR_404</h1>
        <p className="font-mono text-sm text-muted-foreground mb-8">
          THE REQUESTED ASSET COULD NOT BE LOCATED WITHIN THE VAULT. IT MAY HAVE BEEN PURGED OR MOVED TO A SECURE SECTOR.
        </p>
        
        <Link href="/" className="inline-block px-6 py-3 bg-foreground text-background font-mono font-bold hover:bg-accent hover:text-white transition-colors">
          RETURN_TO_HOME
        </Link>
      </div>
    </div>
  );
}
