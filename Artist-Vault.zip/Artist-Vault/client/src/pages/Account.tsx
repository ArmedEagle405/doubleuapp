import { Layout } from "@/components/Layout";
import { useAuth } from "@/hooks/use-auth";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

export default function Account() {
  const { user, isLoading, isAuthenticated, logout } = useAuth();
  const [redirecting, setRedirecting] = useState(false);

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      setRedirecting(true);
      window.location.href = "/api/login";
    }
  }, [isAuthenticated, isLoading]);

  if (isLoading || redirecting) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <span className="font-mono text-muted-foreground animate-pulse">LOADING_ACCOUNT...</span>
        </div>
      </Layout>
    );
  }

  if (!user) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-64">
          <span className="font-mono text-muted-foreground">REDIRECTING_TO_LOGIN...</span>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <h1 className="text-5xl md:text-7xl font-black font-mono tracking-tighter mb-8">
            ACCOUNT
          </h1>

          <div className="border border-border p-8 bg-card/50 space-y-6">
            <div>
              <label className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                Email
              </label>
              <p className="text-2xl font-mono mt-2 text-foreground">{user.email || "N/A"}</p>
            </div>

            {user.firstName && (
              <div>
                <label className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                  Name
                </label>
                <p className="text-2xl font-mono mt-2 text-foreground">
                  {user.firstName} {user.lastName || ""}
                </p>
              </div>
            )}

            <div className="pt-6 border-t border-border">
              <Button
                onClick={() => logout()}
                variant="destructive"
                className="w-full"
                data-testid="button-logout-account"
              >
                LOGOUT
              </Button>
            </div>
          </div>
        </motion.div>
      </section>
    </Layout>
  );
}
