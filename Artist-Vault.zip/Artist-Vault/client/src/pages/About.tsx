import { Layout } from "@/components/Layout";
import { motion } from "framer-motion";
import { Mail, Globe, Instagram, Terminal } from "lucide-react";

export default function About() {
  return (
    <Layout>
      <div className="max-w-3xl mx-auto pt-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="space-y-12"
        >
          {/* Header */}
          <header className="border-b border-border pb-8">
            <h1 className="text-5xl font-mono font-bold tracking-tighter mb-4">
              ABOUT<br />DOUBLEU
            </h1>
            <div className="flex items-center gap-2 text-xs font-mono text-accent">
              <span className="w-2 h-2 bg-accent rounded-full animate-ping" />
              MUSIC_STREAMING
            </div>
          </header>

          {/* Bio Content */}
          <div className="prose prose-invert prose-lg max-w-none font-sans font-light leading-relaxed">
            <p className="first-letter:text-5xl first-letter:font-mono first-letter:float-left first-letter:mr-3 first-letter:mt-[-10px]">
              DoubleU is a rising hip-hop and R&B artist creating innovative sounds that blend 
              classic soul with modern production. This platform serves as the official hub for 
              fans to listen, connect, and experience exclusive content directly from the artist.
            </p>
            <p>
              From debut albums to unreleased tracks, music videos, and behind-the-scenes content—
              everything is here. Follow releases, interact with the music, and join the community 
              of DoubleU fans worldwide.
            </p>
          </div>

          {/* Stats / Tech Specs */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-8 border-y border-border">
            <div className="p-4 bg-secondary/20 border border-border/50">
              <div className="text-xs font-mono text-muted-foreground mb-1">ALBUMS_RELEASED</div>
              <div className="text-2xl font-bold font-mono">2</div>
            </div>
            <div className="p-4 bg-secondary/20 border border-border/50">
              <div className="text-xs font-mono text-muted-foreground mb-1">TOTAL_TRACKS</div>
              <div className="text-2xl font-bold font-mono">24</div>
            </div>
            <div className="p-4 bg-secondary/20 border border-border/50">
              <div className="text-xs font-mono text-muted-foreground mb-1">GENRE</div>
              <div className="text-xl font-bold font-mono truncate">HIP_HOP/R&B</div>
            </div>
            <div className="p-4 bg-secondary/20 border border-border/50">
              <div className="text-xs font-mono text-muted-foreground mb-1">STATUS</div>
              <div className="text-xl font-bold font-mono text-accent">ACTIVE</div>
            </div>
          </div>

          {/* Contact / Links */}
          <div className="space-y-6">
            <h3 className="font-mono text-xl font-bold flex items-center gap-2">
              <Terminal className="w-5 h-5 text-muted-foreground" />
              COMM_CHANNELS
            </h3>
            
            <div className="grid sm:grid-cols-3 gap-4">
              <a href="#" className="flex items-center gap-3 p-4 border border-border hover:bg-white/5 transition-colors group">
                <Mail className="w-5 h-5 group-hover:text-accent transition-colors" />
                <span className="font-mono text-sm">EMAIL_ME</span>
              </a>
              <a href="#" className="flex items-center gap-3 p-4 border border-border hover:bg-white/5 transition-colors group">
                <Instagram className="w-5 h-5 group-hover:text-accent transition-colors" />
                <span className="font-mono text-sm">INSTAGRAM</span>
              </a>
              <a href="#" className="flex items-center gap-3 p-4 border border-border hover:bg-white/5 transition-colors group">
                <Globe className="w-5 h-5 group-hover:text-accent transition-colors" />
                <span className="font-mono text-sm">WEBSITE</span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </Layout>
  );
}
