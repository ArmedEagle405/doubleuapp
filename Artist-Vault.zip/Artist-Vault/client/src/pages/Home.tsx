import { Layout } from "@/components/Layout";
import { useCollections } from "@/hooks/use-collections";
import { CollectionCard } from "@/components/CollectionCard";
import { Loader2, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const { data: collections, isLoading, error } = useCollections();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="mb-20 pt-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-4xl"
        >
          <div className="inline-block px-3 py-1 mb-6 border border-accent/50 text-accent font-mono text-xs tracking-widest bg-accent/5">
            // DOUBLEU_MUSIC_V1
          </div>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-black font-mono tracking-tighter mb-8 text-outline md:text-foreground">
            DOUBLE<br className="md:hidden" />U
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl font-light border-l-2 border-accent pl-6 py-2">
            Experience the music, connect with the artist, and explore exclusive content from DoubleU.
          </p>
        </motion.div>
      </section>

      {/* Grid Status */}
      <div className="flex items-center justify-between mb-8 border-b border-border pb-4">
        <h2 className="text-lg font-mono font-bold flex items-center gap-2">
          <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
          AVAILABLE_ALBUMS
        </h2>
        <span className="text-xs font-mono text-muted-foreground hidden sm:inline-block">
          TOTAL_ALBUMS: {collections?.length || 0}
        </span>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="h-64 flex flex-col items-center justify-center gap-4 text-muted-foreground">
          <Loader2 className="w-8 h-8 animate-spin" />
          <span className="font-mono text-sm animate-pulse">ACCESSING_DATABASE...</span>
        </div>
      ) : error ? (
        <div className="h-64 flex flex-col items-center justify-center gap-4 text-destructive">
          <AlertCircle className="w-8 h-8" />
          <span className="font-mono text-sm">SYSTEM_ERROR: {error.message}</span>
        </div>
      ) : collections?.length === 0 ? (
        <div className="h-64 flex flex-col items-center justify-center gap-4 text-muted-foreground border border-dashed border-border">
          <span className="font-mono text-sm">NO_ALBUMS_YET</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {collections?.map((collection, index) => (
            <CollectionCard 
              key={collection.id} 
              collection={collection} 
              index={index} 
            />
          ))}
        </div>
      )}
    </Layout>
  );
}
