import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertArtwork } from "@shared/schema";

// GET /api/collections/:id/artworks
export function useArtworks(collectionId: number) {
  return useQuery({
    queryKey: [api.artworks.list.path, collectionId],
    queryFn: async () => {
      const url = buildUrl(api.artworks.list.path, { id: collectionId });
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch artworks");
      return api.artworks.list.responses[200].parse(await res.json());
    },
    enabled: !!collectionId,
  });
}

// POST /api/artworks
export function useCreateArtwork() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertArtwork) => {
      const res = await fetch(api.artworks.create.path, {
        method: api.artworks.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create artwork");
      return api.artworks.create.responses[201].parse(await res.json());
    },
    onSuccess: (_, variables) => {
      // Invalidate the specific collection list
      queryClient.invalidateQueries({ 
        queryKey: [api.artworks.list.path, variables.collectionId] 
      });
      // Also could invalidate the collection detail view if it embeds artworks
      queryClient.invalidateQueries({ queryKey: [api.collections.get.path] });
    },
  });
}
