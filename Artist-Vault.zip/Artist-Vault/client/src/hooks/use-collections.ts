import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl } from "@shared/routes";
import { type InsertCollection, type Collection } from "@shared/schema";

// GET /api/collections
export function useCollections() {
  return useQuery({
    queryKey: [api.collections.list.path],
    queryFn: async () => {
      const res = await fetch(api.collections.list.path);
      if (!res.ok) throw new Error("Failed to fetch collections");
      return api.collections.list.responses[200].parse(await res.json());
    },
  });
}

// GET /api/collections/:slug
export function useCollection(slug: string) {
  return useQuery({
    queryKey: [api.collections.get.path, slug],
    queryFn: async () => {
      const url = buildUrl(api.collections.get.path, { slug });
      const res = await fetch(url);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch collection");
      return api.collections.get.responses[200].parse(await res.json());
    },
    enabled: !!slug,
  });
}

// POST /api/collections
export function useCreateCollection() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertCollection) => {
      const res = await fetch(api.collections.create.path, {
        method: api.collections.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to create collection");
      return api.collections.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.collections.list.path] });
    },
  });
}
